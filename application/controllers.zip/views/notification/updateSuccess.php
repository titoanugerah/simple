<div class="alert alert-success alert-dismissible">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <h4><i class="icon fa fa-ban"></i>Berhasil</h4>
  Update Akun berhasil dilakukan, silahkan login kembali untuk mendapatkan data terbaru
</div>
