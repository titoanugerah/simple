<div class="alert alert-warning alert-dismissible">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <h4><i class="icon fa fa-ban"></i>Tambahkan Perangkat</h4>
  Setiap klien dapat memiliki perangkat lebih dari satu, untuk menambahkanya silahkan masukan data data berikut ini, kemudian klik tombol hijau yang terletak pada bawah form
</div>
